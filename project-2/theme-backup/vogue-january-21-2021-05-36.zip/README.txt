      This custom site theme export is based on the theme: Vogue
      It was generated January 21, 2021 05:36.
      Files in this export can be edited to your liking, however renaming or removing any file
      may result in a corrupt import.
      To import this theme, its original file structure must be maintained.
