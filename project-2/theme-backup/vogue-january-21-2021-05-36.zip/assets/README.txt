Theme assets go in this folder
